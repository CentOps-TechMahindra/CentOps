SCHEMA_NAME=$1
SCHEMA_PASSWORD=$2
DB_SID=$3
TB_FS=$4
sqlplus "$SCHEMA_NAME"/"$SCHEMA_PASSWORD"@"$DB_SID" <<EOF >> db_install.log
        set serveroutput on
@./SQL/delta_script_CENTOPS_upgrade_V2_2_V3.sql $TB_FS
@./SQL/CENTOPS_V2_to_V3_INITIAL_DATA.sql
exit
EOF

