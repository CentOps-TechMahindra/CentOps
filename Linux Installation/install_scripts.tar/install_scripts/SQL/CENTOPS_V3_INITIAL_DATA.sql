 --DML Initial DATA --
INSERT INTO PS_USR_MGMT_LEVEL (LVL_ID, LVL_NAME, LVL_SCOPE, LVL_DESC, LVL_DEFAULT) VALUES (1, 'Read Only', 'DEFAULT', 'Read only access', 'Y');
INSERT INTO PS_USR_MGMT_LEVEL (LVL_ID, LVL_NAME, LVL_SCOPE, LVL_DESC, LVL_DEFAULT) VALUES (5, 'Executor', 'Executor', 'Executor', 'N');
INSERT INTO PS_USR_MGMT_LEVEL (LVL_ID, LVL_NAME, LVL_SCOPE, LVL_DESC, LVL_DEFAULT) VALUES (10, 'ADMIN', 'ALL', 'ADMIN', 'N');
COMMIT;


INSERT INTO PS_USR_PROFILE (PRF_ID, PRF_NAME, PRF_SCOPE, PRF_DESC, PRF_DEFAULT) VALUES (1, 'Production Support', 'Production Support', 'Production Support', 'N');
INSERT INTO PS_USR_PROFILE (PRF_ID, PRF_NAME, PRF_SCOPE, PRF_DESC, PRF_DEFAULT) VALUES (2, 'Infra', 'Infra', 'Infra', 'N');
INSERT INTO PS_USR_PROFILE (PRF_ID, PRF_NAME, PRF_SCOPE, PRF_DESC, PRF_DEFAULT) VALUES (3, 'Operations', 'Operations', 'Operations', 'N');
INSERT INTO PS_USR_PROFILE (PRF_ID, PRF_NAME, PRF_SCOPE, PRF_DESC, PRF_DEFAULT) VALUES (4, 'Development', 'Development', 'Development', 'N');
INSERT INTO PS_USR_PROFILE (PRF_ID, PRF_NAME, PRF_SCOPE, PRF_DESC, PRF_DEFAULT) VALUES (5, 'ADBA', 'ADBA', 'ADBA', 'N');
COMMIT;

-- APP URL FEATURE ENTRY
INSERT INTO APP_URL_LIST (SRNO, APPNAME, DESCRIP, URL, LIC, ISFEATURE, IMGNAME, ISDISABLED, ISINSTALLED) VALUES (1, 'Error Trends', 'Error Trends', '/eer/report.htm', 'Yes', 1, 'Error_Trends', 1,  1);
INSERT INTO APP_URL_LIST (SRNO, APPNAME, DESCRIP, URL, LIC, ISFEATURE, IMGNAME, ISDISABLED, ISINSTALLED) VALUES (2, 'Find Solutions', 'Find Solutions', '/eer/search.htm', 'Yes', 1, 'Find_Solutions', 1,  1);
INSERT INTO APP_URL_LIST (SRNO, APPNAME, DESCRIP, URL, LIC, ISFEATURE, IMGNAME, ISDISABLED, ISINSTALLED) VALUES (3, 'My Knowledge Repository', 'My Knowledge Repository', '/PocWork/home.action', 'Yes', 1, 'My_Knowledge_Repository', 1,  1);
INSERT INTO APP_URL_LIST (SRNO, APPNAME, DESCRIP, URL, LIC, ISFEATURE, IMGNAME, ISDISABLED, ISINSTALLED) VALUES (4, 'My Reports', 'My Reports', '/Configurator/pages/configuratorAction.do?action=getPortal', 'Yes', 1, 'My_Reports', 1,  1);
COMMIT;


--------------------------------------------------------
--  Insert Default Data
--------------------------------------------------------

Insert into PS_GAUGE_LABELS (FIRSTGAUGENAME,SECONDGAUGENAME,MINRANGE,MAXRANGE,DATAINFO,DATAQUERY,ISARCHIVED,REFRESHRATE) values ('NAME','NAME',0,40000,'Transactions / Hr','select ''0'' as pcounts, ''0'' as vcounts, to_char(sysdate, ''HH24:mi'') as htime from dual',0,120000);
COMMIT;


--------------------------------------------------------
--  Insert Default Data
--------------------------------------------------------

Insert into PS_LINE_LABELS (LINEHEADER,XTITLE,YTITLE,XRANGE,XINTERVAL,LQUERY,REFRESHRATE) values ('NAME','Hours','Counts','0-23','1 
','select batch_no, stream, ''0'' as File_Count from (select * from (SELECT to_number(to_char(sysdate-level/24,''HH24'')) batch_no, ''X'' flg FROM dual where to_char(sysdate-level/24,''HH24'') <= to_char(sysdate, ''HH24'')  CONNECT BY Level <=24 order by batch_no) batch_no join (select ''DATA 1'' Stream, ''X'' flg from dual union select ''DATA 2'' Stream , ''X'' flg from dual) stream on stream.flg = batch_no.flg order by batch_no) order by  stream, BATCH_NO asc ',900000);
COMMIT;

--------------------------------------------------------
--  Insert Default Data
--------------------------------------------------------

Insert into APP_TBL_MASTER (APP_NAME,TBL_ID,TBL_NAME,TBL_QUERY) values ('appname',1,'Table Tittle','select ''TEXT'' priority, ''0'' as cnt, ''0'' as Critical  from dual');
Insert into APP_TBL_MASTER (APP_NAME,TBL_ID,TBL_NAME,TBL_QUERY) values ('appname',2,'Table Tittle','select ''TEXT'' as Name, ''0'' as Total_cnt, ''0'' as Total_complaint from dual');
Insert into APP_TBL_MASTER (APP_NAME,TBL_ID,TBL_NAME,TBL_QUERY) values ('appname',3,'Table Tittle','select ''TEXT'' as SUB_APP_NAME, ''0'' as MOTS, ''0'' as AVAILIBILITY from dual');
COMMIT;

--------------------------------------------------------
--  Insert Default Data
--------------------------------------------------------  

Insert into APP_TBL_COLUMN (TBL_ID,TBL_COLUMN) values (1,'HEADER 1');
Insert into APP_TBL_COLUMN (TBL_ID,TBL_COLUMN) values (1,'HEADER 2');
Insert into APP_TBL_COLUMN (TBL_ID,TBL_COLUMN) values (2,'HEADER 1');
Insert into APP_TBL_COLUMN (TBL_ID,TBL_COLUMN) values (2,'HEADER 2');
Insert into APP_TBL_COLUMN (TBL_ID,TBL_COLUMN) values (2,'HEADER 3');
Insert into APP_TBL_COLUMN (TBL_ID,TBL_COLUMN) values (3,'HEADER 1');
Insert into APP_TBL_COLUMN (TBL_ID,TBL_COLUMN) values (3,'HEADER 2');
Insert into APP_TBL_COLUMN (TBL_ID,TBL_COLUMN) values (3,'HEADER 3');
COMMIT;

--------------------------------------------------------
--  Insert Default Data
-------------------------------------------------------- 
Insert into AVAILABLE_DATABASE_TYPES (DATABASE_ID,DATABASE_TYPE) values (1,'ORACLE');
Insert into AVAILABLE_DATABASE_TYPES (DATABASE_ID,DATABASE_TYPE) values (2,'MYSQL');
COMMIT;


Insert into USER_INFORMATION (ID,USER_ID,F_NAME,L_NAME,ADMIN,PASSWORD) values (1,'GUEST','Guest','Guest','yes','GUEST');

COMMIT;

