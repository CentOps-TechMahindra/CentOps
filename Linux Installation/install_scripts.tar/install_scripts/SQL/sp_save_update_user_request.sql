create or replace
PROCEDURE SP_SAVE_UPDATE_USER_REQUEST
( P_USER_ID IN VARCHAR2
, P_REQUESTED_LVL_ID IN NUMBER
, P_REQUESTED_APP_ID IN NUMBER
, P_REQUESTED_PRF_ID IN NUMBER
, P_USER_TEAM IN VARCHAR2
, P_STATUS IN VARCHAR2
, P_COMMENT IN VARCHAR2
, P_RESULT OUT NUMBER
, P_MESSAGE OUT VARCHAR2
) AS
BEGIN
    DECLARE
    V_EXISTS NUMBER;
    V_REQUEST_ID NUMBER;
    BEGIN
        V_REQUEST_ID :=0;
        dbms_output.put_line(V_REQUEST_ID);
        IF P_USER_ID IS NULL OR P_USER_ID='' THEN
            P_RESULT := 0;
            P_MESSAGE := 'User ID missing';
            RETURN;
        END IF;
        
        IF P_REQUESTED_LVL_ID IS NULL OR P_REQUESTED_LVL_ID='' THEN
            P_RESULT := 0;
            P_MESSAGE := 'Requested Level ID missing';
            RETURN;
        END IF;
        
        IF P_REQUESTED_APP_ID IS NULL OR P_REQUESTED_APP_ID='' THEN
            P_RESULT := 0;
            P_MESSAGE := 'Requested App ID missing';
            RETURN;
        END IF;
        
        IF P_REQUESTED_PRF_ID IS NULL OR P_REQUESTED_PRF_ID='' THEN
            P_RESULT := 0;
            P_MESSAGE := 'Requested Profile ID missing';
            RETURN;
        END IF;
        
        IF P_USER_TEAM IS NULL OR P_USER_TEAM='' THEN
            P_RESULT := 0;
            P_MESSAGE := 'User Team missing';
            RETURN;
        END IF;
        
        IF P_STATUS IS NULL OR P_STATUS='' THEN
            P_RESULT := 0;
            P_MESSAGE := 'Status missing';
            RETURN;
        END IF;
        
        IF P_COMMENT IS NULL OR P_COMMENT='' THEN
            P_RESULT := 0;
            P_MESSAGE := 'Requester Comment missing';
            RETURN;
        END IF;
        dbms_output.put_line(V_REQUEST_ID);
        BEGIN
          SELECT REQUEST_ID into V_REQUEST_ID FROM PS_USER_ACCESS_REQUEST WHERE USER_ID = P_USER_ID AND STATUS = 'PENDING';
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
          V_REQUEST_ID := 0;
        END;  
         
            IF V_REQUEST_ID > 0 THEN
              UPDATE PS_USER_ACCESS_REQUEST SET REQUESTED_LVL_ID = P_REQUESTED_LVL_ID, REQUESTED_APP_ID = P_REQUESTED_APP_ID, REQUESTED_PRF_ID = P_REQUESTED_PRF_ID, REQUESTER_COMMENT = P_COMMENT WHERE REQUEST_ID = V_REQUEST_ID;
              
              UPDATE PS_USERS SET USER_TEAM = P_USER_TEAM WHERE USER_ID = P_USER_ID;
            ELSIF V_REQUEST_ID <= 0 THEN
              INSERT INTO PS_USER_ACCESS_REQUEST (USER_ID, REQUESTED_LVL_ID, REQUESTED_APP_ID, REQUESTED_PRF_ID, STATUS, REQUESTER_COMMENT) VALUES (P_USER_ID, P_REQUESTED_LVL_ID, P_REQUESTED_APP_ID, P_REQUESTED_PRF_ID, P_STATUS, P_COMMENT);
              
              UPDATE PS_USERS SET USER_TEAM = P_USER_TEAM WHERE USER_ID = P_USER_ID;
            ELSE
              P_RESULT := 2;
              P_MESSAGE := 'Unable to save request!';
              RETURN;
            END IF;
          
        COMMIT;
        P_RESULT := 0;
        P_MESSAGE := 'SUCCCESS';    
    END;
EXCEPTION
    WHEN OTHERS THEN
        P_RESULT := -1;
        P_MESSAGE := SQLERRM;    
        ROLLBACK;    
END SP_SAVE_UPDATE_USER_REQUEST;
