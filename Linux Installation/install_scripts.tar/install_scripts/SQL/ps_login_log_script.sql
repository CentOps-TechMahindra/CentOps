--PS_USER_LOGIN_LOG 
CREATE TABLE PS_USER_LOGIN_LOG 
(
  LOG_ID NUMBER NOT NULL 
, USER_ID VARCHAR2(20) 
, LOG_IN_DATE DATE 
, CONSTRAINT PS_USER_LOGIN_LOG_PK PRIMARY KEY 
  (
    LOG_ID 
  )
  ENABLE 
);


-- SEQUENCE
create sequence user_login_log_id_seq start with 1 increment by 1 nocache;

-- Trigger
--CREATE TRIGGER
CREATE or REPLACE
TRIGGER GEN_PS_USER_LOGIN_LOG  BEFORE INSERT ON PS_USER_LOGIN_LOG
FOR EACH ROW BEGIN
      IF inserting THEN
        IF :NEW.LOG_ID IS NULL THEN
            SELECT user_login_log_id_seq.nextval INTO :NEW.LOG_ID FROM dual;      
        END IF;   
    END IF; 
END;
/
