SCHEMA_NAME=$1
SCHEMA_PASSWORD=$2
DB_SID=$3
USR=$4
FName=$5
LName=$6
eML=$7
Phne=$8
Team=$9
sqlplus "$SCHEMA_NAME"/"$SCHEMA_PASSWORD"@"$DB_SID" <<EOF >> db_install.log
        set serveroutput on
INSERT INTO PS_USERS (USER_ID, USER_FNAME, USER_LNAME, USER_EMAIL_ID, USER_CONTACT_NO,USER_TEAM, LVL_ID, PRF_ID) VALUES ('$USR', '$FName', '$LName', '$eML', '$Phne', '$Team', 10, 2);
commit
EOF

