$( "form" ).submit(function( event ) {
	var appName 		= $('[name=appName]')	.val();
	var desc 			= $("#desc")			.val();
	var isValidAppName	= $("#isValidAppName")	.val();
	var motsId			= $("#motsId")			.val();
	
	var flag = true;
	var msg = "Below field(s) are mandatory:\n";
	
	if( appName == ""){
		msg += "-Application Name.\n";
		flag = false;
	}else if( isValidAppName != "true"){
		msg += "-Please enter Valid Application Name.\n";
		flag = false;
	}
	
	if( motsId != "" & isNaN(motsId)){
		msg += "-Please enter valid MOTS ID.\n";
		flag = false;
	}else if( motsId == 0){
		msg += "-MOTS ID.\n";
		flag = false;
	}
	
	if( desc == ""){
		msg += "-Description.\n";
		flag = false;
	}
	
	if (flag) {
		return true;
	}else{
		alert(msg);
		event.preventDefault();
	}
});