package model;

public class compData {
	    private String Name;
	    private int Total;
	    private int Total_Complaint;
		public String getName() {
			return Name;
		}
		public void setName(String name) {
			Name = name;
		}
		public int getTotal() {
			return Total;
		}
		public void setTotal(int total) {
			Total = total;
		}
		public int getTotal_Complaint() {
			return Total_Complaint;
		}
		public void setTotal_Complaint(int total_Complaint) {
			Total_Complaint = total_Complaint;
		}
		
}
