package model;

public class Availibility {
	
	private String appName;
	private int mots;
	private int ava;
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public int getMots() {
		return mots;
	}
	public void setMots(int mots) {
		this.mots = mots;
	}
	public int getAva() {
		return ava;
	}
	public void setAva(int ava) {
		this.ava = ava;
	}
	
	public Availibility() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Availibility(String appName, int mots, int ava) {
		super();
		this.appName = appName;
		this.mots = mots;
		this.ava = ava;
	}
	
	@Override
	public String toString() {
		return "Availibility [appName=" + appName + ", mots=" + mots + ", ava="
				+ ava + "]";
	}
	
	

}
