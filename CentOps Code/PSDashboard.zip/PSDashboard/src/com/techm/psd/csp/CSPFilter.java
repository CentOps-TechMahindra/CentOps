package com.techm.psd.csp;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.techm.psd.common.dao.CommonDAO;
import com.techm.psd.common.dao.CommonDAOImpl;
import com.techm.psd.common.dto.UserDTO;
import com.techm.psd.common.utils.AppConfig;
import com.techm.psd.common.utils.LDAPUtility;
import com.techm.psd.common.utils.UserSessionUtil;
import com.techm.psd.constants.CommonConstants;
import com.techm.psd.constants.LDAP_CONSTANTS;
import com.techm.psd.constants.SQLConstants;
import com.techm.psd.csp.CSPFilterConstants;
import com.techm.psd.user.dao.UserDAOImpl;

import esGateKeeper.esGateKeeper;

public class CSPFilter implements Filter {
	
	private static final Logger LOGGER 							= Logger.getLogger(CSPFilter.class);
	
	
	public static List<String>bypassList;
	private static FilterConfig filterConfig;
	
	public void init(FilterConfig aFilterConfig) throws ServletException {	
		CSPFilterConstants.WEB_APP_ROOT = CSPFilterConstants.FORWARD_SLASH + aFilterConfig.getServletContext().getServletContextName() + CSPFilterConstants.FORWARD_SLASH;
		LOGGER.info("Init is called, Web Root:  " + CSPFilterConstants.WEB_APP_ROOT);
		
		this.filterConfig = aFilterConfig;
		bypassList = new ArrayList<String>();
		//bypassList.add("home.do");
	}
	
	public void destroy() {}
	
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		LOGGER.info("Enters in doFilter()...");
		
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		String uri = httpRequest.getRequestURI();
		HttpSession session = httpRequest.getSession();
		ServletContext context=filterConfig.getServletContext();
		LOGGER.info("Checking for CSP cookie...URI: " + uri);
				
		if(uri.contains("logout.do")){
			LOGGER.info("Enters in CSPFilter.logout...");
			HttpServletResponse httpResponse = (HttpServletResponse) response;
			httpResponse.setStatus(302);
			String url = "";
			LOGGER.info("Exit from CSPFilter.logout and redirecting to Gloabl Logon... URL::::::::::: "+url);
			httpResponse.sendRedirect(url);
		}else{
			String url2= null;
	        StringBuilder sb = new StringBuilder();
	        sb.append(httpRequest.getRequestURL().toString());
	        
	        if(httpRequest.getQueryString() != null){
	        	sb.append("?"+httpRequest.getQueryString());
	        }
	        url2 = sb.toString();
        	
            if ( uri.indexOf("/css") > 0){
                chain.doFilter(request, response);
            }
            else if( uri.indexOf("/styles") > 0){
                chain.doFilter(request, response);
            }
            else if( uri.indexOf("/images") > 0){
                chain.doFilter(request, response);
            }
            else if( uri.indexOf("/js") > 0){
                chain.doFilter(request, response);
            }
            
			if (session.getAttribute("user") != null || session.getAttribute("uri") != null) {
				chain.doFilter(request, response);
	        } else {
	        	session.setAttribute("uri", url2);
	        	filterConfig.getServletContext().getRequestDispatcher("/pages/authentication/login.jsp").forward(request, response);
	        }//Check userAuthCookie.
			
			//context.getRequestDispatcher("/pages/authentication/login.jsp").forward(request, response);
		}
	}//ends doFilter()
	
}