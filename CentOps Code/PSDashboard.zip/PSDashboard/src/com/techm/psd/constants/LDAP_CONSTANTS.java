package com.techm.psd.constants;

public class LDAP_CONSTANTS {

	public static final String _LDAP_PROBLEM	= "LDAP_DOWN";
	public static final String _LDAP_DOWN_URL	= "/pages/error/genericError.jsp";
	
}
