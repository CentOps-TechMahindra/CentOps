package com.techm.psd.common.utils;

public class LDAPUtility {

}
