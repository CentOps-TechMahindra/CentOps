package com.techm.psd.common.utils;

import org.apache.log4j.Logger;
import com.techm.psd.common.utils.AppConfig;

public class AppPropertiesReader {
	private static Logger LOGGER = Logger.getLogger(AppConfig.class);
	
	static String _GROUP_MECH_ID = "";					// Default id is ''
	
	public static final String getGroupMechID() {
		return _GROUP_MECH_ID;
	}

}
