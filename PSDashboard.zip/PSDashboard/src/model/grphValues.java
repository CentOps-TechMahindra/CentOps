package model;

import java.util.ArrayList;

public class grphValues {
	private String stream;
	private ArrayList values;
	public String getStream() {
		return stream;
	}
	public void setStream(String stream) {
		this.stream = stream;
	}
	public ArrayList getValues() {
		return values;
	}
	public void setValues(ArrayList arrayList) {
		this.values = arrayList;
	}
}
