package model;

public class getter {
private int BATCH_NO;
private int FILE_COUNT;
private String STREAM;
public int getBATCH_NO() {
	return BATCH_NO;
}
public void setBATCH_NO(int bATCH_NO) {
	BATCH_NO = bATCH_NO;
}
public int getFILE_COUNT() {
	return FILE_COUNT;
}
public void setFILE_COUNT(int fILE_COUNT) {
	FILE_COUNT = fILE_COUNT;
}
public String getSTREAM() {
	return STREAM;
}
public void setSTREAM(String sTREAM) {
	STREAM = sTREAM;
}
}